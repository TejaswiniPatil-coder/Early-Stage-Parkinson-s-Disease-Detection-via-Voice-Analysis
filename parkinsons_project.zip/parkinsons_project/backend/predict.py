import joblib
import numpy as np
import csv, os
from datetime import datetime

MODEL_PATH = '../models/trained_model.pkl'
RESULTS_PATH = '../results/prediction_results.csv'

FEATURE_COLUMNS = [
    'MDVP:Fo(Hz)', 'MDVP:Fhi(Hz)', 'MDVP:Flo(Hz)',
    'MDVP:Jitter(%)', 'MDVP:Jitter(Abs)', 'MDVP:RAP', 'MDVP:PPQ',
    'Jitter:DDP', 'MDVP:Shimmer', 'MDVP:Shimmer(dB)',
    'Shimmer:APQ3', 'Shimmer:APQ5', 'MDVP:APQ', 'Shimmer:DDA',
    'NHR', 'HNR', 'RPDE', 'DFA', 'spread1', 'spread2', 'D2', 'PPE'
]

def predict_from_csv_features(features: dict, name: str = "Unknown"):
    model = joblib.load(MODEL_PATH)
    input_vector = np.array([[features.get(col, 0.0) for col in FEATURE_COLUMNS]])
    prediction = int(model.predict(input_vector)[0])
    probability = float(model.predict_proba(input_vector)[0][prediction]) * 100

    label = "Parkinson Detected" if prediction == 1 else "Healthy"

    os.makedirs(os.path.dirname(RESULTS_PATH), exist_ok=True)
    file_exists = os.path.isfile(RESULTS_PATH)
    with open(RESULTS_PATH, 'a', newline='') as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(['Name', 'Timestamp', 'Prediction', 'Confidence(%)'])
        writer.writerow([name, datetime.now().strftime('%Y-%m-%d %H:%M'), label, f"{probability:.1f}"])

    return {
        'name': name,
        'prediction': prediction,
        'label': label,
        'confidence': round(probability, 1),
        'features': {
            'jitter': round(features.get('MDVP:Jitter(%)', 0), 5),
            'shimmer': round(features.get('MDVP:Shimmer', 0), 5),
            'hnr': round(features.get('HNR', 0), 2),
            'ppe': round(features.get('PPE', 0), 5),
        }
    }
