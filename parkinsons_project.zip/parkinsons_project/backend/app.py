from flask import Flask, request, jsonify, render_template
import os, sys
sys.path.append(os.path.dirname(__file__))
from predict import predict_from_csv_features
from feature_extraction import extract_features_from_audio

app = Flask(__name__, template_folder='../frontend', static_folder='../frontend')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/results')
def results():
    return render_template('results.html')

@app.route('/predict', methods=['POST'])
def predict():
    if 'audio' in request.files:
        audio_file = request.files['audio']
        audio_path = "../audio_samples/temp_input.wav"
        audio_file.save(audio_path)
        features = extract_features_from_audio(audio_path)
    else:
        features = {k: float(v) for k, v in request.form.items() if k != 'name'}
    name = request.form.get('name', 'Unknown')
    result = predict_from_csv_features(features, name)
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
