import librosa
import numpy as np

def extract_features_from_audio(audio_path: str) -> dict:
    """
    Extract voice features from a .wav audio file.
    Maps librosa features to Parkinson's dataset features.
    """
    y, sr = librosa.load(audio_path, sr=None)

    # Fundamental frequency (pitch)
    f0, voiced_flag, _ = librosa.pyin(y, fmin=75, fmax=600)
    f0_voiced = f0[voiced_flag]
    fo  = float(np.mean(f0_voiced)) if len(f0_voiced) > 0 else 150.0
    fhi = float(np.max(f0_voiced))  if len(f0_voiced) > 0 else 200.0
    flo = float(np.min(f0_voiced))  if len(f0_voiced) > 0 else 100.0

    jitter = float(np.std(f0_voiced) / (np.mean(f0_voiced) + 1e-6)) if len(f0_voiced) > 0 else 0.005

    rms = librosa.feature.rms(y=y)[0]
    shimmer = float(np.std(rms) / (np.mean(rms) + 1e-6))

    harmonic, percussive = librosa.effects.hpss(y)
    hnr = float(10 * np.log10(np.sum(harmonic**2) / (np.sum(percussive**2) + 1e-6) + 1e-6))

    mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
    rpde  = float(np.std(mfccs[1]))
    dfa   = float(np.mean(np.abs(np.diff(mfccs[0]))))
    ppe   = float(np.std(f0_voiced) / (fo + 1e-6)) if len(f0_voiced) > 0 else 0.2

    return {
        'MDVP:Fo(Hz)': fo, 'MDVP:Fhi(Hz)': fhi, 'MDVP:Flo(Hz)': flo,
        'MDVP:Jitter(%)': jitter * 100, 'MDVP:Jitter(Abs)': jitter * fo / 1000,
        'MDVP:RAP': jitter * 0.5, 'MDVP:PPQ': jitter * 0.6,
        'Jitter:DDP': jitter * 1.5,
        'MDVP:Shimmer': shimmer, 'MDVP:Shimmer(dB)': abs(20 * np.log10(shimmer + 1e-6)),
        'Shimmer:APQ3': shimmer * 0.7, 'Shimmer:APQ5': shimmer * 0.8,
        'MDVP:APQ': shimmer * 0.9, 'Shimmer:DDA': shimmer * 2.0,
        'NHR': 1 / (hnr + 1e-6), 'HNR': hnr,
        'RPDE': rpde, 'DFA': dfa,
        'spread1': -5.0 + rpde, 'spread2': 0.2 + dfa,
        'D2': 2.0 + rpde * 0.1, 'PPE': ppe
    }
