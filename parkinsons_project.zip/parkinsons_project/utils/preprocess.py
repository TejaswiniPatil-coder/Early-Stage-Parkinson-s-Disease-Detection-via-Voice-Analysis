import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

def load_and_preprocess(path='../dataset/parkinsons.csv'):
    df = pd.read_csv(path)
    df.drop(columns=['name'], inplace=True, errors='ignore')
    X = df.drop(columns=['status'])
    y = df['status']
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=42, stratify=y
    )
    return X_train, X_test, y_train, y_test, scaler, X.columns.tolist()
