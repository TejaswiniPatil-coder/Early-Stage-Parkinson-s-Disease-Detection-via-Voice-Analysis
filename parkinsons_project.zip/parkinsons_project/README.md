# Parkinson's Disease Detection - Voice Tremor Analysis

## Quick Start (3 Steps)

### Step 1 — Install Python dependencies
```bash
pip install -r requirements.txt
```

### Step 2 — Download dataset & train the model
1. Download `parkinsons.csv` from: https://archive.ics.uci.edu/ml/datasets/parkinsons
2. Place it in the `dataset/` folder
3. Run:
```bash
cd notebooks
python train_model.py
```

### Step 3 — Start the web app
```bash
cd backend
python app.py
```
Open your browser at **http://localhost:5000**

---

## How to Use the App
1. Enter the patient's name
2. Upload a .wav voice recording (5–10 seconds of saying "Aaaah")
3. Click **Analyze Voice**
4. See the result: Healthy or Parkinson Detected (with confidence %)

---

## Project Structure
```
parkinsons_detection_project/
├── dataset/              ← Put parkinsons.csv here
├── models/               ← trained_model.pkl (auto-generated)
├── audio_samples/        ← Test .wav files
├── notebooks/
│   └── train_model.py    ← Run this first!
├── backend/
│   ├── app.py            ← Flask web server
│   ├── predict.py        ← ML prediction logic
│   └── feature_extraction.py  ← Librosa audio features
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── results/              ← Charts + prediction_results.csv
├── utils/
│   └── preprocess.py
└── requirements.txt
```

---

## Dataset Source
UCI Machine Learning Repository — Parkinson's Disease Dataset
https://archive.ics.uci.edu/ml/datasets/parkinsons

---

## Disclaimer
This tool is for educational/research purposes only. Not a substitute for professional medical diagnosis.
