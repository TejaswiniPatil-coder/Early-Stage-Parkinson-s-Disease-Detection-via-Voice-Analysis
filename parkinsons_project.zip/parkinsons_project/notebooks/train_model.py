"""
HOW TO RUN:
  cd notebooks
  python train_model.py

OUTPUT:
  ../models/trained_model.pkl  (best model, ready for web app)
  ../models/scaler.pkl         (feature scaler)
  ../results/model_comparison.png
  ../results/confusion_matrix.png
"""
import pandas as pd
import numpy as np
import joblib, os
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

# ── 1. Load dataset ──────────────────────────────────────────────────────────
df = pd.read_csv('../dataset/parkinsons.csv')
df.drop(columns=['name'], inplace=True, errors='ignore')
X = df.drop(columns=['status'])
y = df['status']

# ── 2. Scale features ────────────────────────────────────────────────────────
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42, stratify=y
)

# ── 3. Train 5 models ────────────────────────────────────────────────────────
models = {
    'Logistic Regression': LogisticRegression(max_iter=1000),
    'SVM':                 SVC(probability=True, kernel='rbf'),
    'Random Forest':       RandomForestClassifier(n_estimators=100, random_state=42),
    'KNN':                 KNeighborsClassifier(n_neighbors=5),
    'Gradient Boosting':   GradientBoostingClassifier(n_estimators=100, random_state=42)
}

results = {}
for name, model in models.items():
    model.fit(X_train, y_train)
    acc = accuracy_score(y_test, model.predict(X_test))
    results[name] = acc
    print(f"  {name:25s}: {acc*100:.2f}%")

# ── 4. Save best model ───────────────────────────────────────────────────────
best_name = max(results, key=results.get)
best_model = models[best_name]
print(f"\nBest model: {best_name} ({results[best_name]*100:.2f}%)")
os.makedirs('../models', exist_ok=True)
joblib.dump(best_model, '../models/trained_model.pkl')
joblib.dump(scaler,     '../models/scaler.pkl')
print("Saved: ../models/trained_model.pkl")

# ── 5. Accuracy comparison chart ─────────────────────────────────────────────
os.makedirs('../results', exist_ok=True)
plt.figure(figsize=(10, 5))
colors = ['#3498db', '#2ecc71', '#e74c3c', '#f39c12', '#9b59b6']
bars = plt.bar(results.keys(), [v * 100 for v in results.values()], color=colors)
plt.ylim(70, 100)
plt.title('Model Accuracy Comparison', fontsize=14)
plt.ylabel('Accuracy (%)')
plt.xticks(rotation=15)
for bar, val in zip(bars, results.values()):
    plt.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.3,
             f'{val*100:.1f}%', ha='center', fontsize=9)
plt.tight_layout()
plt.savefig('../results/model_comparison.png', dpi=120)
print("Chart saved: ../results/model_comparison.png")

# ── 6. Confusion matrix ───────────────────────────────────────────────────────
cm = confusion_matrix(y_test, best_model.predict(X_test))
plt.figure(figsize=(6, 5))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
            xticklabels=['Healthy', 'Parkinson'],
            yticklabels=['Healthy', 'Parkinson'])
plt.title(f'Confusion Matrix – {best_name}')
plt.ylabel('Actual')
plt.xlabel('Predicted')
plt.tight_layout()
plt.savefig('../results/confusion_matrix.png', dpi=120)
print("Confusion matrix saved: ../results/confusion_matrix.png")
print("\nAll done! Now run: cd ../backend && python app.py")
