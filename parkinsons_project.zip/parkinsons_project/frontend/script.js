function onFileChosen(input) {
  const area      = document.getElementById('uploadArea');
  const fileChosen = document.getElementById('fileChosen');
  if (input.files && input.files[0]) {
    area.classList.add('has-file');
    fileChosen.textContent = '✅ ' + input.files[0].name;
    fileChosen.classList.remove('hidden');
  }
}

async function analyzeAudio() {
  const name      = document.getElementById('patientName').value.trim() || 'Unknown';
  const audioFile = document.getElementById('audioFile').files[0];
  const resultDiv = document.getElementById('result');
  const loader    = document.getElementById('loader');
  const btn       = document.getElementById('analyzeBtn');

  if (!audioFile) {
    alert('Please upload a voice sample (.wav) first!');
    return;
  }

  // Show loader, hide result
  resultDiv.className = 'result hidden';
  loader.classList.remove('hidden');
  btn.disabled = true;
  btn.innerHTML = '<span>⏳</span> Analyzing...';

  const formData = new FormData();
  formData.append('name',  name);
  formData.append('audio', audioFile);

  try {
    const response = await fetch('/predict', { method: 'POST', body: formData });
    if (!response.ok) throw new Error('Server error');
    const data = await response.json();

    const cls  = data.prediction === 1 ? 'positive' : 'negative';
    const icon = data.prediction === 1 ? '⚠️' : '✅';
    const conf = data.confidence;

    resultDiv.innerHTML = `
      <p class="result-patient">Analysis Result</p>
      <p class="result-name">${data.name}</p>

      <div class="result-status">
        <div class="status-dot"></div>
        <div class="result-label">${icon} ${data.label}</div>
      </div>

      <div class="confidence-bar-wrap">
        <div class="confidence-label">
          <span>Confidence Score</span>
          <strong>${conf}%</strong>
        </div>
        <div class="confidence-bar">
          <div class="confidence-fill" id="confFill"></div>
        </div>
      </div>

      <p class="features-title">Voice Feature Breakdown</p>
      <div class="features-grid">
        <div class="feature-box">
          <span class="f-label">Jitter</span>
          <span class="f-value">${data.features.jitter}</span>
          <span class="f-desc">Frequency variation</span>
        </div>
        <div class="feature-box">
          <span class="f-label">Shimmer</span>
          <span class="f-value">${data.features.shimmer}</span>
          <span class="f-desc">Amplitude variation</span>
        </div>
        <div class="feature-box">
          <span class="f-label">HNR</span>
          <span class="f-value">${data.features.hnr} dB</span>
          <span class="f-desc">Harmonic to noise ratio</span>
        </div>
        <div class="feature-box">
          <span class="f-label">PPE</span>
          <span class="f-value">${data.features.ppe}</span>
          <span class="f-desc">Pitch period entropy</span>
        </div>
      </div>
    `;

    resultDiv.className = `result ${cls}`;

    // Animate confidence bar after render
    setTimeout(() => {
      const fill = document.getElementById('confFill');
      if (fill) fill.style.width = conf + '%';
    }, 100);

  } catch (err) {
    resultDiv.innerHTML = `
      <p style="color:var(--danger); font-weight:600; margin-bottom:8px">
        ❌ Could not connect to server.
      </p>
      <p style="font-size:0.88rem; color:var(--text-muted)">
        Make sure Flask is still running in your Command Prompt.<br/>
        Command: <code style="background:var(--surface2); padding:2px 6px; border-radius:4px;">cd backend &amp;&amp; python app.py</code>
      </p>`;
    resultDiv.className = 'result';
  } finally {
    loader.classList.add('hidden');
    btn.disabled = false;
    btn.innerHTML = '<span>🔬</span> Analyze Voice';
  }
}
